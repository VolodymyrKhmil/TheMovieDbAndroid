package com.khmil.volodymyr.movieapi;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestHandle;

import org.apache.http.Header;

class Configurations {
    public ImageInfo images;
    public String[] change_keys;
}

class ImageInfo {
    public String base_url;
    public String secure_base_url;
    public String[] backdrop_sizes;
    public String[] logo_sizes;
    public String[] poster_sizes;
    public String[] profile_sizes;
    public String[] still_sizes;
}

interface movieService {
    public void getTopRated(int page, final RequestMovieCaller caller);

    public void getPopular(int page, final RequestMovieCaller caller);

    public void getUpcoming(int page, final RequestMovieCaller caller);

    public void getConfiguration(final RequestMovieCaller caller);

    public String buildBackdropURL(ImageInfo imageInfo, MovieInfo movieInfo);

    public String buildPosterURL(ImageInfo imageInfo, MovieInfo movieInfo);

    public void search(int page, String query, final RequestMovieCaller caller);
}

interface RequestMovieCaller {
    public void refreshAllData(MoviesInfo newData);

    public void refreshConfiguration(Configurations configuration);

    public void onRequestFailAction(String message, int statusCode);
}

public class Service implements movieService {
    @Override
    public void search(int page, String query, final RequestMovieCaller caller) {
        getMoviesByType(page, caller, "/search/movie?query=" + query + "&");
    }

    @Override
    public String buildBackdropURL(ImageInfo imageInfo, MovieInfo movieInfo) {
        return imageInfo.base_url + imageInfo.backdrop_sizes[0] + movieInfo.backdrop_path;
    }

    @Override
    public String buildPosterURL(ImageInfo imageInfo, MovieInfo movieInfo) {
        return imageInfo.base_url + imageInfo.poster_sizes[0] + movieInfo.poster_path;
    }

    @Override
    public void getTopRated(int page, final RequestMovieCaller caller) {
        getMoviesByType(page, caller, "/movie/top_rated?");
    }

    @Override
    public void getPopular(int page, final RequestMovieCaller caller) {
        getMoviesByType(page, caller, "/movie/popular?");
    }

    @Override
    public void getUpcoming(int page, final RequestMovieCaller caller) {
        getMoviesByType(page, caller, "/movie/upcoming?");
    }

    private void getMoviesByType(int page, final RequestMovieCaller caller, String type) {
        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("starting", "check check");

        RequestHandle handler = client.get(baseURL + type + api_key + "&page=" + String.valueOf(page),
                new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                        String json = new String(responseBody);
                        Gson gson = new Gson();
                        MoviesInfo response = gson.fromJson(json, MoviesInfo.class);
                        caller.refreshAllData(response);
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, byte[] responseBody,
                                          Throwable error) {
                        caller.onRequestFailAction(new String(responseBody), statusCode);
                    }
                });
    }

    @Override
    public void getConfiguration(final RequestMovieCaller caller) {
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(baseURL + "/configuration?" + api_key, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String json = new String(responseBody);
                Gson gson = new Gson();
                Configurations response = gson.fromJson(json, Configurations.class);
                caller.refreshConfiguration(response);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody,
                                  Throwable error) {
                caller.onRequestFailAction(new String(responseBody), statusCode);
            }
        });
    }

    private String baseURL = "http://api.themoviedb.org/3";
    private String api_key = "api_key=6a6898a77f85aca22483f3b05a6b2a59";
}

