package com.khmil.volodymyr.movieapi;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class SingleFilmWidget extends View {
    SingleFilmWidget(Context context, MovieInfo info, Bitmap bitmap) {
        super(context);
        this.info = info;
        layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        _infoButton = new Button(context);
        _infoButton.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        _image = new ImageView(context);
        _image.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        _image.setImageBitmap(bitmap);
        _fullInfo = new TextView(context);
        _fullInfo.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        _fullInfo.setVisibility(View.GONE);
        layout.addView(_image);
        layout.addView(_infoButton);
        mainLayout = new LinearLayout(context);
        mainLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.addView(layout);
        mainLayout.addView(_fullInfo);
        setListeners();
        initWithMovieInfo(info);
    }

    public void initWithMovieInfo(MovieInfo info) {
        _infoButton.setText(info.original_title);
        _fullInfo.setText(info.original_title + "\n" + " Release Date : " + info.release_date + "\n");
        //_image.setImageBitmap(info.imagePosterPath);
    }

    private void setListeners() {
        _infoButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (_fullInfo.getVisibility() == View.GONE)
                    _fullInfo.setVisibility(View.VISIBLE);
                else
                    _fullInfo.setVisibility(View.GONE);
            }
        });
    }

    public void setImage(Bitmap bitmap) {
        _image.setImageBitmap(bitmap);
        //layout.addView(_image);
    }

    public LinearLayout getInstance() {
        return mainLayout;
    }

    private Button _infoButton;
    private ImageView _image;
    private LinearLayout layout;
    private LinearLayout mainLayout;
    private final TextView _fullInfo;
    private MovieInfo info;
}
