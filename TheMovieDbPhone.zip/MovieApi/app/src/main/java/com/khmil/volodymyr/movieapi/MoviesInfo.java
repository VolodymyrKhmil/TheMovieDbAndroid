package com.khmil.volodymyr.movieapi;

public class MoviesInfo {
    public int page;
    public MovieInfo[] results;
    public int total_pages;
    public int total_results;
}
