package com.khmil.volodymyr.movieapi;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;


public class MainActivity extends ActionBarActivity implements RequestMovieCaller {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        _mainLayout = new LinearLayout(this);
        _mainLayout.setOrientation(LinearLayout.VERTICAL);
        _mainLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        _topLayout = new LinearLayout(this);
        _topLayout.setOrientation(LinearLayout.HORIZONTAL);
        _topLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        spinnerInit(this);
        _search = new EditText(this);
        _search.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        _searchButton = new Button(this);
        _searchButton.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        _topLayout.addView(_spinner);
        _topLayout.addView(_searchButton);
        _topLayout.addView(_search);

        _bottomLayout = new LinearLayout(context);
        _bottomLayout.setOrientation(LinearLayout.VERTICAL);
        _bottomLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        sv = new ScrollView(context);
        sv.addView(_bottomLayout);

        _mainLayout.addView(_topLayout, 0);
        _mainLayout.addView(sv, 1);

        dbService = new Service();
        dbService.getConfiguration(this);
        _moreButton = new Button(context);
        _moreButton.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(_mainLayout);
        makeDesign();
        setListeners();
    }
    private void setListeners() {
        _moreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isMorePicked = true;
                getNewDataByLatOperation(_lastOperation == LastOperation.search ? ++search_counter
                        : ++_currentPagesViewed);
                setIsCurrentlyRequested(true);
            }
        });
        _spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getNewDataBySpinnerValue(1);
                setIsCurrentlyRequested(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        _search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (_search.getText().length() == 0)
                    _searchButton.setEnabled(false);
                else
                    _searchButton.setEnabled(true);
            }
        });
        _searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                searchData(1);
                setIsCurrentlyRequested(true);
            }
        });
    }
    @Override
    public void onRequestFailAction(String message, int statusCode) {
        _mainLayout.removeAllViews();
        _errorText = new TextView(this);
        _errorText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        _errorText.setText(message);
        _mainLayout.addView(_errorText);
    }

    private void makeDesign() {
        _search.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xFFFFFFFF);
        gd.setCornerRadius(20);
        gd.setStroke(1, 0xFF000000);
        _moreButton.setBackground(gd);
        _moreButton.setText("View More");
        _searchButton.setEnabled(false);
        _searchButton.setText("Search");
        _search.setSingleLine(true);
        _search.setMaxLines(1);
        _search.setLines(1);
        _search.setCursorVisible(false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void getTopRated(int page) {
        dbService.getTopRated(page, this);
        _lastOperation = LastOperation.topRated;
    }

    private void getUpcoming(int page) {
        dbService.getUpcoming(page, this);
        _lastOperation = LastOperation.upcoming;
    }

    private void getPopular(int page) {
        dbService.getPopular(page, this);
        _lastOperation = LastOperation.popular;
    }

    private void getNewDataByLatOperation(int page) {
        if (_lastOperation == LastOperation.search) {
            searchData(search_counter);
        }
        else if (_lastOperation == LastOperation.popular)
            getPopular(page);
        else if (_lastOperation == LastOperation.topRated)
            getTopRated(page);
        else if (_lastOperation == LastOperation.upcoming)
            getUpcoming(page);
    }

    private void getNewDataBySpinnerValue(int page) {
        switch (_spinner.getSelectedItem().toString()) {
            case "TopRated":
                getTopRated(page);
                break;
            case "Upcoming":
                getUpcoming(page);
                break;
            case "Popular":
                getPopular(page);
                break;
        }
    }

    private void searchData(int page) {
        search_counter = page;
        dbService.search(page, _search.getText().toString(), this);
        _lastOperation = LastOperation.search;
    }

    @Override
    public void refreshAllData(MoviesInfo newData) {
        _moviesInfo = newData;
        if (_filmsArray == null)
            _filmsArray = new ArrayList<SingleFilmWidget>();
        _amountOfPages = newData.total_pages;
        _currentPagesViewed = newData.page;
        new LoadData().execute(newData);
    }

    @Override
    public void refreshConfiguration(Configurations configuration) {
        _config = configuration;
        this.getNewDataBySpinnerValue(1);
    }

    private void setIsCurrentlyRequested(boolean enabled) {
        _spinner.setEnabled(!enabled);
        if (_currentPagesViewed < _amountOfPages && _currentPagesViewed < MAX_PAGES)
            _moreButton.setEnabled(!enabled);
        if (_search.getText().length() != 0)
            _searchButton.setEnabled(!enabled);
        _search.setEnabled(!enabled);
    }

    private void spinnerInit(Context context) {
        ArrayList<String> spinnerArray = new ArrayList<String>();
        spinnerArray.add("TopRated");
        spinnerArray.add("Upcoming");
        spinnerArray.add("Popular");
        _spinner = new Spinner(context);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(context,
                android.R.layout.simple_spinner_dropdown_item, spinnerArray);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        _spinner.setAdapter(spinnerArrayAdapter);
    }

    enum LastOperation {
        search,
        topRated,
        popular,
        upcoming
    }

    private LinearLayout _bottomLayout;
    private LinearLayout _topLayout;
    private LinearLayout _mainLayout;
    private Spinner _spinner;
    private Button _moreButton;
    private EditText _search;
    private Button _searchButton;
    private Context context;
    private TextView _errorText;
    private ScrollView sv;

    private movieService dbService;
    private ArrayList<SingleFilmWidget> _filmsArray;
    private MoviesInfo _moviesInfo;
    private Configurations _config;

    private boolean isMorePicked = false;
    private int _amountOfPages;
    private int _currentPagesViewed;
    private final int MAX_PAGES = 1000;
    private int search_counter = 1; // because server has bug =)

    private LastOperation _lastOperation;

    class LoadData extends AsyncTask<MoviesInfo, String, Bitmap[]> {
        private Bitmap[] _images;
        @Override
        protected void onPreExecute() {

        }

        protected Bitmap[] doInBackground(MoviesInfo... args) {
            try {
                 _images = new Bitmap[args[0].results.length];
                for (int i = 0; i < args[0].results.length; ++i)
                {
                    URL url = new URL(dbService.buildPosterURL(_config.images, args[0].results[i]));
                    HttpGet httpRequest = null;

                    httpRequest = new HttpGet(url.toURI());

                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = (HttpResponse) httpclient
                            .execute(httpRequest);

                    HttpEntity entity = response.getEntity();
                    BufferedHttpEntity b_entity = new BufferedHttpEntity(entity);
                    InputStream input = b_entity.getContent();

                    _images[i] = BitmapFactory.decodeStream(input);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return _images;
        }
        @Override
        protected void onPostExecute(Bitmap[] images) {

            try {
                if (!isMorePicked) {
                    _filmsArray.clear();
                    _bottomLayout.removeAllViews();
                } else
                    _bottomLayout.removeViewAt(_bottomLayout.getChildCount() - 1);
                for (int i = 0; i < _moviesInfo.results.length; ++i) {
                    _filmsArray.add(new SingleFilmWidget(context, _moviesInfo.results[i], _images[i]));
                }
                for (int i = _bottomLayout.getChildCount(); i < _filmsArray.size(); ++i)
                    _bottomLayout.addView(_filmsArray.get(i).getInstance());
                _bottomLayout.addView(_moreButton);
                isMorePicked = false;
                setIsCurrentlyRequested(false);
                isMorePicked = false;
                setIsCurrentlyRequested(false);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}


